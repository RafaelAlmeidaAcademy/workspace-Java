
public class Simulator {

    public static void main (String args[])
    {
        SanduicheStore store = new SanduicheStore();
        store.orderSanduiche();
    }
}