public class XEgg extends Sanduiches{



    public void prepare(){
        super.prepare();
        this.toppings.add("Egg");
    }
}
