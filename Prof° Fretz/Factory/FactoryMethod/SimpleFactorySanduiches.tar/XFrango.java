public class XFrango extends Sanduiches
{

       public void prepare(){
        super.prepare();
        this.toppings.add("Chicken");
    }
}