public class XBacon extends Sanduiches{

    public void prepare(){
        super.prepare();
        this.toppings.add("Bacon");
    }

}