public class XTudo extends Sanduiches{

    public void prepare(){
        super.prepare();
        this.toppings.add("Egg");
        this.toppings.add("Chicken");
        this.toppings.add("Bacon");
    }
}